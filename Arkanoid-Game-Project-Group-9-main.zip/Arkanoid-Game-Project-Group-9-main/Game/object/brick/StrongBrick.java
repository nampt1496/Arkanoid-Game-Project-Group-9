package Game.object.brick;

import java.awt.Color;

public class StrongBrick extends Brick {

    public StrongBrick(int x, int y, int width, int height, Color color, int hitsRequired) {
        super(x, y, width, height, color, hitsRequired);
        //TODO Auto-generated constructor stub
    }}