package Game.GamePlay;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class GameState extends JPanel {
    private Runnable onResume;
    private Runnable onExit;
    private Runnable onBackToMenu;

    public GameState(Runnable onResume, Runnable onExit, Runnable onBackToMenu) {
        this.onResume = onResume;
        this.onExit = onExit;
        this.onBackToMenu = onBackToMenu;

        setLayout(new GridBagLayout());
        setBackground(new Color(0, 0, 0, 180)); // nửa trong suốt

        JButton resumeBtn = new JButton("Tiếp tục");
        JButton exitBtn = new JButton("Thoát (lưu điểm)");
        JButton menuBtn = new JButton("Về menu chính");

        resumeBtn.addActionListener((ActionEvent e) -> onResume.run());
        exitBtn.addActionListener((ActionEvent e) -> onExit.run());
        menuBtn.addActionListener((ActionEvent e) -> onBackToMenu.run());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridy = 0; add(resumeBtn, gbc);
        gbc.gridy = 1; add(exitBtn, gbc);
        gbc.gridy = 2; add(menuBtn, gbc);
    }
}
