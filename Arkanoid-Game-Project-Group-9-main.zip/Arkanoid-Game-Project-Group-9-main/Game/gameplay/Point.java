package Game.GamePlay;

public class Point {
    private int score;

    public Point() {
        this.score = 0;
    }

    // tăng điểm
    public void addScore(int value) {
        score += value;
    }

    // đặt lại điểm
    public void reset() {
        score = 0;
    }

    public int getScore() {
        return score;
    }

    @Override
    public String toString() {
        return "Score: " + score;
    }
}
