package Game.GamePlay;

public class Lives {
    private int lives;
    private final int maxLives = 3;

    public Lives() {
        this.lives = maxLives;
    }

    // mất mạng
    public void loseLife() {
        if (lives > 0) {
            lives--;
        }
    }

    // thêm mạng (nếu cần)
    public void addLife() {
        if (lives < maxLives) {
            lives++;
        }
    }

    // đặt lại số mạng
    public void reset() {
        lives = maxLives;
    }

    public int getLives() {
        return lives;
    }

    public boolean isDead() {
        return lives <= 0;
    }

    @Override
    public String toString() {
        return "Lives: " + lives;
    }
}
