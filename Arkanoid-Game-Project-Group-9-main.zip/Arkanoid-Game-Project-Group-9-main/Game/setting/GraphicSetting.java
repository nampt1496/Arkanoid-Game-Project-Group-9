package Game.setting;

public class GraphicSetting {}