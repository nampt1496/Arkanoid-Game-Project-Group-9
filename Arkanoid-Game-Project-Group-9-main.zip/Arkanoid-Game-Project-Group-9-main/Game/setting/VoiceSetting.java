package Game.setting;

public class VoiceSetting {}