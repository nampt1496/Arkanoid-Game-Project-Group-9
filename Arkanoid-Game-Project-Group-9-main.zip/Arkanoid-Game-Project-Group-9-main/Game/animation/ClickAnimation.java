package Game.animation;

public class ClickAnimation {}