package Game.animation;

public class CollideAnimation {}