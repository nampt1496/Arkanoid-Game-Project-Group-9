# Arkanoid Java Project
Generated base structure for game development.
