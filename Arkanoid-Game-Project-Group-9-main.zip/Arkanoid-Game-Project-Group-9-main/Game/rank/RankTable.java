package Game.rank;

public class RankTable {}