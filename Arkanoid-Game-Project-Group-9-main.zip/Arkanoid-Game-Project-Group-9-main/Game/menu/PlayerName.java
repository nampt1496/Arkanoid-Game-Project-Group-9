package Game.menu;

public class PlayerName {
    private String name;
    public PlayerName(String name) { this.name = name; }
}