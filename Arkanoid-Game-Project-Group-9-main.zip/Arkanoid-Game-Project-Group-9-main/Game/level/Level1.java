package Game.level;

public class Level1 extends BaseLevel {}